CREATE TABLE Pelicula
(
  id_pelicula NUMBER PRIMARY KEY
, titulo VARCHAR2(20)
, duracion NUMBER
);

CREATE TABLE Sesion
(
  id_pelicula NUMBER FOREIGN KEY REFERENCES Pelicula(id_pelicula)
, fecha_hora DATE
, PRIMARY KEY
  (
    id_pelicula
  , fecha_hora
  )
);

CREATE TABLE Producto
(
  id_producto NUMBER PRIMARY KEY
, precio FLOAT
);

CREATE TABLE EntradaAsocia 
(
  id_producto NUMBER
, id_pelicula NUMBER
, fecha_hora DATE 
, FOREIGN KEY (id_producto, id_pelicula, fecha_hora) REFERENCES Producto(id_producto, id_pelicula, fecha_hora)
, PRIMARY KEY
  (
    id_producto
  , id_pelicula
  , fecha_hora
  )
);

CREATE TABLE Consumible
(
  id_producto NUMBER PRIMARY KEY FOREIGN KEY REFERENCES Producto(id_producto)
, nombre VARCHAR2(20)
);

CREATE TABLE Regalo
(
  id_regalo NUMBER PRIMARY KEY
, precio FLOAT
);

CREATE TABLE Catering
(
  id_catering NUMBER PRIMARY KEY
, precio NUMBER
);

CREATE TABLE Cliente
(
  dni_cliente VARCHAR2(9) PRIMARY KEY
, nombre VARCHAR2(20)
, telefono VARCHAR2(9)
);

CREATE TABLE Turno
(
  id_turno NUMBER PRIMARY KEY
, tipo VARCHAR2(20)
, hora_inicio DATE
, hora_fin DATE
);

CREATE TABLE Empleado
(
  dni_empleado VARCHAR2(9) PRIMARY KEY
, nombre VARCHAR2(20)
, id_turno NUMBER NOT NULL FOREIGN KEY REFERENCES Turno(id_turno)

);

CREATE TABLE Evento
(
  id_evento NUMBER PRIMARY KEY
, precio NUMBER
, fecha_hora DATE
, dni_cliente NOT NULL FOREING KEY REFERENCES Cliente(dni_cliente)
, dni_empleado NOT NULL FOREING KEY REFERENCES Empleado(dni_empleado)
, id_regalo NUMBER FOREIGN KEY REFERENCES Regalo(id_regalo)
, id_catering NUMBER FOREIGN KEY REFERENCES Catering(id_catering)
);

CREATE TABLE Asistencia
(
  id_asistencia NUMBER PRIMARY KEY
, localizacion VARCHAR2(20)
);

CREATE TABLE Ficha
(
  dni_empleado VARCHAR2(9) FOREIGN KEY REFERENCES Empleado(dni_empleado)
, id_asistencia NUMBER FOREIGN KEY REFERENCES Asistencia(id_asistencia)
, fecha_hora DATE
, PRIMARY KEY(dni_empleado, id_asistencia, fecha_hora)
);

CREATE TABLE Nomina
(
  id_nomina NUMBER PRIMARY KEY
, importe NUMBER
, fecha DATE
, dni_empleado VARCHAR2(9) NOT NULL FOREIGN KEY REFERENCES Empleado(dni_empleado)
);

CREATE TABLE CompraIncluye
(
  id_compra NUMBER PRIMARY KEY
, importe NUMBER
, fecha_hora DATE
, id_producto NUMBER NOT NULL FOREIGN KEY Producto(id_producto)
);

CREATE TABLE AsientoContable
(
  id_asiento NUMBER PRIMARY KEY
);

CREATE TABLE AsientoCompra
(
  id_asiento NUMBER PRIMARY KEY FOREIGN KEY REFERENCES AsientoContable(id_asiento)
, cantidad NUMBER
, id_compra NUMBER NOT NULL FOREIGN KEY CompraIncluye(id_compra)
);

CREATE TABLE AsientoEvento
(
  id_asiento NUMBER PRIMARY KEY FOREIGN KEY REFERENCES AsientoContable(id_asiento)
, cantidad NUMBER
, id_evento NUMBER NOT NULL FOREIGN KEY REFERENCES Evento(id_evento)
);

CREATE TABLE AsientoNomina
(
  id_asiento NUMBER PRIMARY KEY FOREIGN KEY REFERENCES AsientoContable(id_asiento)
, cantidad NUMBER
, id_nomina NUMBER NOT NULL FOREIGN KEY REFERENCES Nomina(id_nomina)
);
